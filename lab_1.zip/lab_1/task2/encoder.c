#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void encryption(int enc_op, char* enc_chars, FILE* inFile, FILE* outFile) {
    
    int len = strlen(enc_chars);
    char c;

    while(!(feof(inFile)))
    {
        for(int i=0; i<len; i++)
        {
            int enc = enc_chars[i];
            c = fgetc(inFile);
            if (c == '\n')
            {
                if(enc_op) c = c - enc;
                else c = c + enc;
                fputc(c, outFile);                            
                fputc('\n', outFile);
                break;
            }
            if(enc_op) c = c - enc;
            else c = c + enc;
            fputc(c, outFile);
            if(feof(inFile)) break;//This extra-check is needed when reading input from a file
        }                    
    }        
}

int main(int argc, char **argv) {
    
    int debug_mode = 0, enc_mode = 0, enc_op = 0, inFile_mode = 0, outFile_mode = 0, inFile_name = 0, outFile_name = 0;
    FILE* inFile = stdin;
    FILE* outFile = stdout;
    char* enc_chars;
    char c;

    for(int i=1; i<argc; i++)
    {
        //Task 1b with an input/output-file option        
        if(argv[i][1] == 'D')
        {
            debug_mode = 1;
            for(int l=1; l<argc; l++) fprintf(stderr, "%s", argv[l]);
            fprintf(stderr, "\n");
            
            for(int j=i; j<argc; j++)
            {
                if(argv[j][1] == 'i')
                {
                    inFile_mode = 1;
                    inFile_name = j;                  
                }
                if(argv[j][1] == 'o')
                {
                    outFile_mode = 1;
                    outFile_name = j;                  
                } 
            }
        } 
        //Task 1c with an input/output-file option
        else if(argv[i][1] == 'e')
        {
            enc_mode = 1;
            if(argv[i][0] == '-') enc_op = 1;
            enc_chars = argv[i] + 2;

            for(int j=i; j<argc; j++)
            {
                if(argv[j][1] == 'i')
                {
                    inFile_mode = 1;
                    inFile_name = j;                  
                }
                if(argv[j][1] == 'o')
                {
                    outFile_mode = 1;
                    outFile_name = j;                  
                }     
            }           
        }
        //Task 1a with an input/output-file option
        else 
        {
            if(argv[i][1] == 'i')
            {
                inFile_mode = 1;
                inFile_name = i;                  
            }
            if(argv[i][1] == 'o')
            {
                outFile_mode = 1;
                outFile_name = i;                  
            } 
        }     
    }//End of main for-loop

    
    while(!(feof(inFile))) 
    {
        if(inFile_mode)
        {
            char* name = argv[inFile_name] + 2;
            inFile = fopen(name, "r");
            if(inFile == NULL)
            {
                fprintf(stderr, "Input file cannot be opened for reading. exit program.\n");
                return -1;
            }
        }
        if(outFile_mode)
        {
            char* name = argv[outFile_name] + 2;
            outFile = fopen(name, "w");
            if(outFile == NULL)
            {
                fprintf(stderr, "Output file cannot be opened for writing. exit program.\n");
                return -1;
            }
        }
        if(enc_mode) 
        {
            encryption(enc_op, enc_chars, inFile, outFile);
            break; //Exit this loop 
        }
        
        else
        {
            c = fgetc(inFile);
            if(c>64 && c<91) 
            {
                if(debug_mode) fprintf(stderr, "%#04x\t%#04x\n", c, c+0x20); 
                c=c+32;
            }
            else if(debug_mode) fprintf(stderr, "%#04x\t%#04x\n", c, c);
            fputc(c, outFile);
        }
    }//End of while-loop
        
    fprintf(outFile, "\n");
    fclose(inFile);
    return(0);
    
}